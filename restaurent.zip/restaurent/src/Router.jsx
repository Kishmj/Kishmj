import React from 'react';
import { Route, Routes  } from "react-router-dom";
import HomePage from './component/Home';
import About from './component/About';

const Routing = () => (
            <Routes>
               <Route path='/'element={<HomePage/>}/>
               <Route path='/About'element={<About/>}/>
            </Routes>    
            );
            

export default Routing
