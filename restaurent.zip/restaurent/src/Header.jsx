import React from 'react'
import './Header.css'
import { Link } from 'react-router-dom'

Link
const Header = () => {
  return (
      <div className="header">
        <div className="logo">
            <img src="./assets/images/random.png" alt="" />
        </div>

        <div className="menus">
            <Link to="/">
                <h4>Home</h4>
            </Link>
            <Link to="About">
                <h4>About Us</h4>
            </Link>
            <Link to="Home">
                <h4>Our Menu</h4>
            </Link>
            <Link to="Home">
                <h4>Contact Us</h4>
            </Link>
        </div>

      </div>
   
  )
}

export default Header
