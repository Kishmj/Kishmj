
import './App.css'
import React from 'react'
import Routing from './Router'
import Header from './Header'
Header



function App() {
  return (
    <>
    <Header />
   <Routing />
    
    </>
  )
}

export default App
