import React from 'react'

const About = () => {
  return (
    <div>
      <p>hi this is daniel</p>
    </div>
  )
}

export default About
