import React from 'react'


function HomePage() {
  return (
    <>
      <div className="homepage">
        <p>Kishore is heare</p>
      </div>
    </>
  )
}

export default HomePage
