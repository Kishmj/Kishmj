import "./App.css";
import React, { useState } from "react";
import UserTable from "./component/UserTable";
import Update from "./component/Update";
import Edit from "./component/Edit";

function App() {
  const usersdata = [
    { id: 1, name: "kishore", domine: "Reactdeveloper" },
    { id: 2, name: "Daniel", domine: "React Nave" },
    { id: 3, name: "Madesh", domine: "Flutter" },
  ];
  const adduser = (user) => {
    user.id = users.length + 1;
    Setusers([...users, user]);
  };
  const deleteuser = (id) => {
    Setusers(users.filter((user) => user.id !== id));
    Setediting(false);
  };
  const [users, Setusers] = useState(usersdata);
  const [editing, Setediting] = useState(false);
  const intialformstate = { id: null, name: "", domine: "" };
  const [currentuser, setcurrentuser] = useState(intialformstate);
  const editrow = (user) => {
    Setediting(true);
    setcurrentuser({ id: user.id, name: user.name, domine: user.domine });
  };
  const updateuser = (id, updateduser) => {
    Setediting(false);
    Setusers(users.map((user) => (user.id === id ? updateduser : user)));
  };

  return (
    <>
      <div className="crud mx-auto">
        <h1>C-R-U-D Operations</h1>
      </div>
      <div className="row mx-auto">
        <div className="col-md-6">
          {editing ? (
            <div>
 
 
              <h2>Edit User</h2>
              <Edit
                setediting={Setediting}
                currentuser={currentuser}
                updateuser={updateuser}
              />
            </div>
          ) : (
            <div>
              <h2>Update Form</h2>
              <Update adduser={adduser} />
            </div>
          )}
        </div>
        <div className="col-md-6">
          <h2>View Fields</h2>
          <UserTable editrow={editrow} deleteuser={deleteuser} users={users} />
        </div>
      </div>
    </>
  );
}

export default App;
