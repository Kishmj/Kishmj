import React from "react";

const UserTable = (props) => (
  <table className="table table-bordered">
    <thead>
      <tr>
        <th>Name</th>
        <th>Domine</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (
        props.users.map((users) => (
          <tr key={users.id}>
            <td>{users.name}</td>
            <td>{users.domine}</td>
            <td>
              <button onClick={() => props.editrow(users)} className="button">
                Edit
              </button>
              <button
                onClick={() => props.deleteuser(users.id)}
                className="delete"
              >
                Delete
              </button>
            </td>
          </tr>
        ))
      ) : (
        <tr>
          <td colspan={3}>No users</td>
        </tr>
      )}
    </tbody>
  </table>
);

export default UserTable;
