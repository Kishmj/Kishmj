import React, { useState } from "react";

const Update = (props) => {
  const intialformstate = { id: null, name: "", domine: "" };
  const [user, Setusers] = useState(intialformstate);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    Setusers({ ...user, [name]: value });
  };
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!user.name || !user.domine) return;
        props.adduser(user);
        Setusers(intialformstate);
      }}
    >
      <label>Name</label>
      <input
        type="text"
        onChange={handleInputChange}
        placeholder="Enter your Name"
        name="name"
        value={user.name}
      />
      <br />
      <label>Domine</label>
      <input
        type="text"
        placeholder="Work you Belongs to"
        onChange={handleInputChange}
        name="domine"
        value={user.domine}
      />
      <br />
      <button>Add New user</button>
    </form>
  );
};

export default Update;
