import React, { useEffect, useState } from "react";

const Edit = (props) => {
  const [user, Setusers] = useState(props.currentuser);
  useEffect(() => {
    Setusers(props.currentuser);
  }, [props]);
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    Setusers({ ...user, [name]: value });
  };
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        if (!user.name || !user.domine) return;
        props.updateuser(user.id, user);
      }}
    >
      <label>Name</label>
      <input
        type="text"
        onChange={handleInputChange}
        placeholder="Enter your Name"
        name="name"
        value={user.name}
      />
      <br />
      <label>Domine</label>
      <input
        type="text"
        placeholder="Work you Belongs to"
        onChange={handleInputChange}
        name="domine"
        value={user.domine}
      />
      <br />
      <button>Update User</button>
      <button
        onClick={() => {
          props.Setediting(false);
        }}
      >
        cancel
      </button>
    </form>
  );
};

export default Edit;
